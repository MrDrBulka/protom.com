import { useState, useRef } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import Navigation from '@/components/Navigation';
import WaveDivider from '@/components/WaveDivider';
import PronunciationTrainer from '@/components/PronunciationTrainer';
import InteractiveDictionary from '@/components/InteractiveDictionary';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowRight, BookOpen, Music, Palette, Users, Zap, Award, Volume2 } from 'lucide-react';

/**
 * Design Philosophy: "Теплая Традиция" (Warm Tradition)
 * - Warm color palette: brown, terracotta, ochre
 * - Organic, hospitable design
 * - Wavy dividers and texture
 * - Elegant typography with Cormorant Garamond
 * - Smooth animations and micro-interactions
 */

export default function Home() {
  const { t } = useLanguage();
  const [isPronunciationOpen, setIsPronunciationOpen] = useState(false);
  const [isDictionaryOpen, setIsDictionaryOpen] = useState(false);
  const aboutSectionRef = useRef<HTMLDivElement>(null);

  const scrollToAbout = () => {
    aboutSectionRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section id="home" className="relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="/hero-banner.jpg"
            alt="Hero Banner"
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/70 to-transparent"></div>
        </div>

        <div className="relative z-10 container py-16 md:py-32">
          <div className="max-w-2xl">
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-primary mb-6 animate-fade-in-up">
              {t('hero.title')}
            </h1>
            <p className="text-lg sm:text-xl md:text-2xl text-foreground/80 mb-8 leading-relaxed">
              {t('hero.subtitle')}
            </p>
            <div className="flex gap-3 flex-wrap sm:gap-4">
              <Button
                size="lg"
                onClick={() => setIsPronunciationOpen(true)}
                className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-lg shadow-lg hover:shadow-xl transition-all transform hover:scale-105 text-sm sm:text-base"
              >
                {t('hero.cta')}
                <ArrowRight className="ml-2 w-4 sm:w-5 h-4 sm:h-5" />
              </Button>
              <Button
                size="lg"
                onClick={scrollToAbout}
                variant="outline"
                className="border-primary text-primary hover:bg-primary/10 rounded-lg transition-all text-sm sm:text-base"
              >
                {t('nav.about')}
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section ref={aboutSectionRef} id="about" className="py-16 md:py-28 bg-card texture-warm">
        <div className="container">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-primary mb-8 md:mb-12 text-center">
            {t('about.title')}
          </h2>

          <div className="grid md:grid-cols-2 gap-8 md:gap-12 items-center mb-12 md:mb-16">
            <div>
              <p className="text-lg text-foreground/80 mb-6 leading-relaxed">
                {t('about.description')}
              </p>
              <p className="text-foreground/70 leading-relaxed">
                {t('about.additional')}
              </p>
              <Button
                onClick={() => setIsDictionaryOpen(true)}
                variant="outline"
                className="mt-6 border-primary text-primary hover:bg-primary/10"
              >
                <BookOpen className="w-4 h-4 mr-2" />
                {t('about.open.dictionary')}
              </Button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-1 gap-4 sm:gap-6">
              <Card className="p-8 bg-background border-border hover:shadow-lg transition-all transform hover:scale-105 card-warm-hover">
                <div className="flex items-start gap-4">
                  <Users className="w-8 h-8 text-accent flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold text-primary mb-2">{t('about.speakers')}</h3>
                    <p className="text-2xl font-bold text-accent">{t('about.speakers.count')}</p>
                  </div>
                </div>
              </Card>

              <Card className="p-8 bg-background border-border hover:shadow-lg transition-all transform hover:scale-105 card-warm-hover">
                <div className="flex items-start gap-4">
                  <Palette className="w-8 h-8 text-secondary flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold text-primary mb-2">{t('about.official')}</h3>
                    <p className="text-lg text-foreground/80">{t('about.official.country')}</p>
                  </div>
                </div>
              </Card>

              <Card className="p-8 bg-background border-border hover:shadow-lg transition-all transform hover:scale-105 card-warm-hover">
                <div className="flex items-start gap-4">
                  <BookOpen className="w-8 h-8 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold text-primary mb-2">{t('about.family')}</h3>
                    <p className="text-lg text-foreground/80">{t('about.family.type')}</p>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* History Section */}
      <section id="history" className="py-20 md:py-28 bg-background">
        <div className="container">
          <h2 className="text-4xl md:text-5xl font-bold text-primary mb-16 text-center">
            {t('history.title')}
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Ancient */}
            <Card className="p-8 bg-card border-border hover:shadow-lg transition-all transform hover:-translate-y-2 card-warm-hover">
              <div className="mb-4">
                <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center mb-4">
                  <span className="text-2xl">🏛️</span>
                </div>
                <h3 className="text-2xl font-bold text-primary mb-3">{t('history.ancient')}</h3>
              </div>
              <p className="text-foreground/80 leading-relaxed">
                {t('history.ancient.desc')}
              </p>
            </Card>

            {/* Medieval */}
            <Card className="p-8 bg-card border-border hover:shadow-lg transition-all transform hover:-translate-y-2 card-warm-hover">
              <div className="mb-4">
                <div className="w-12 h-12 rounded-lg bg-secondary/20 flex items-center justify-center mb-4">
                  <span className="text-2xl">📜</span>
                </div>
                <h3 className="text-2xl font-bold text-primary mb-3">{t('history.medieval')}</h3>
              </div>
              <p className="text-foreground/80 leading-relaxed">
                {t('history.medieval.desc')}
              </p>
            </Card>

            {/* Modern */}
            <Card className="p-8 bg-card border-border hover:shadow-lg transition-all transform hover:-translate-y-2 card-warm-hover">
              <div className="mb-4">
                <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center mb-4">
                  <span className="text-2xl">🌍</span>
                </div>
                <h3 className="text-2xl font-bold text-primary mb-3">{t('history.modern')}</h3>
              </div>
              <p className="text-foreground/80 leading-relaxed">
                {t('history.modern.desc')}
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Grammar Section - EXPANDED */}
      <section id="grammar" className="py-28 md:py-36 bg-card texture-warm">
        <div className="container">
          <h2 className="text-4xl md:text-5xl font-bold text-primary mb-8 text-center">
            {t('grammar.title')}
          </h2>
          <p className="text-lg text-foreground/80 text-center mb-20 max-w-3xl mx-auto">
            {t('grammar.intro')}
          </p>

          {/* Main Grammar Features */}
          <div className="grid md:grid-cols-3 gap-8 mb-20">
            {/* Agglutination */}
            <div className="space-y-4 p-6 bg-background rounded-lg border border-border hover:border-primary/50 transition-all">
              <div className="w-16 h-16 rounded-lg bg-gradient-to-br from-accent to-secondary/50 flex items-center justify-center">
                <span className="text-3xl">🔤</span>
              </div>
              <h3 className="text-2xl font-bold text-primary">{t('grammar.agglutination')}</h3>
              <p className="text-foreground/80 leading-relaxed">
                {t('grammar.agglutination.desc')}
              </p>
              <p className="text-sm text-foreground/70 pt-2 italic">
                Пример: ат (лошадь) → атым (моя лошадь) → атымда (у меня есть лошадь)
              </p>
            </div>

            {/* Vowel Harmony */}
            <div className="space-y-4 p-6 bg-background rounded-lg border border-border hover:border-primary/50 transition-all">
              <div className="w-16 h-16 rounded-lg bg-gradient-to-br from-secondary to-primary/50 flex items-center justify-center">
                <span className="text-3xl">🎵</span>
              </div>
              <h3 className="text-2xl font-bold text-primary">{t('grammar.vowel')}</h3>
              <p className="text-foreground/80 leading-relaxed">
                {t('grammar.vowel.desc')}
              </p>
              <p className="text-sm text-foreground/70 pt-2 italic">
                {t('grammar.vowel.example')}
              </p>
            </div>

            {/* Cases */}
            <div className="space-y-4 p-6 bg-background rounded-lg border border-border hover:border-primary/50 transition-all">
              <div className="w-16 h-16 rounded-lg bg-gradient-to-br from-primary to-accent/50 flex items-center justify-center">
                <span className="text-3xl">📋</span>
              </div>
              <h3 className="text-2xl font-bold text-primary">{t('grammar.cases')}</h3>
              <p className="text-foreground/80 leading-relaxed">
                {t('grammar.cases.desc')}
              </p>
              <p className="text-sm text-foreground/70 pt-2 italic">
                {t('grammar.cases.example')}
              </p>
            </div>
          </div>

          {/* Additional Grammar Topics */}
          <div className="bg-background rounded-lg p-12 border border-border">
            <h3 className="text-3xl font-bold text-primary mb-12 text-center">{t('grammar.additional')}</h3>
            
            <div className="grid md:grid-cols-2 gap-12">
              {/* Phonetics */}
              <div className="space-y-4">
                <div className="flex items-center gap-3 mb-4">
                  <Zap className="w-6 h-6 text-accent" />
                  <h4 className="text-xl font-bold text-primary">{t('content.phonetics')}</h4>
                </div>
                <p className="text-foreground/80 leading-relaxed">
                  {t('content.phonetics.desc')}
                </p>
              </div>

              {/* Word Order */}
              <div className="space-y-4">
                <div className="flex items-center gap-3 mb-4">
                  <Award className="w-6 h-6 text-secondary" />
                  <h4 className="text-xl font-bold text-primary">{t('content.word.order')}</h4>
                </div>
                <p className="text-foreground/80 leading-relaxed">
                  {t('content.word.order.desc')}
                </p>
              </div>

              {/* Suffixes */}
              <div className="space-y-4">
                <div className="flex items-center gap-3 mb-4">
                  <Zap className="w-6 h-6 text-primary" />
                  <h4 className="text-xl font-bold text-primary">{t('content.suffixes')}</h4>
                </div>
                <p className="text-foreground/80 leading-relaxed">
                  {t('content.suffixes.desc')}
                </p>
              </div>

              {/* Alphabet */}
              <div className="space-y-4">
                <div className="flex items-center gap-3 mb-4">
                  <BookOpen className="w-6 h-6 text-accent" />
                  <h4 className="text-xl font-bold text-primary">{t('content.alphabet')}</h4>
                </div>
                <p className="text-foreground/80 leading-relaxed">
                  {t('content.alphabet.desc')}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Culture Section - EXPANDED */}
      <section id="culture" className="py-28 md:py-36 bg-background">
        <div className="container">
          <h2 className="text-4xl md:text-5xl font-bold text-primary mb-8 text-center">
            {t('culture.title')}
          </h2>
          <p className="text-lg text-foreground/80 text-center mb-20 max-w-3xl mx-auto">
            {t('culture.intro')}
          </p>

          {/* Main Culture Section */}
          <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
            <img
              src="/culture-section.jpg"
              alt="Kazakh Culture"
              className="rounded-lg shadow-lg w-full h-96 object-cover hover:shadow-2xl transition-shadow"
            />
            <div className="space-y-8">
              {/* Music */}
              <div className="flex gap-4 p-4 rounded-lg hover:bg-card/50 transition-all">
                <Music className="w-8 h-8 text-accent flex-shrink-0 mt-1" />
                <div>
                  <h3 className="text-2xl font-bold text-primary mb-2">{t('culture.music')}</h3>
                  <p className="text-foreground/80 leading-relaxed">
                    {t('culture.music.desc')}
                  </p>
                </div>
              </div>

              {/* Crafts */}
              <div className="flex gap-4 p-4 rounded-lg hover:bg-card/50 transition-all">
                <Palette className="w-8 h-8 text-secondary flex-shrink-0 mt-1" />
                <div>
                  <h3 className="text-2xl font-bold text-primary mb-2">{t('culture.crafts')}</h3>
                  <p className="text-foreground/80 leading-relaxed">
                    {t('culture.crafts.desc')}
                  </p>
                </div>
              </div>

              {/* Food */}
              <div className="flex gap-4 p-4 rounded-lg hover:bg-card/50 transition-all">
                <span className="text-3xl flex-shrink-0">🍽️</span>
                <div>
                  <h3 className="text-2xl font-bold text-primary mb-2">{t('culture.food')}</h3>
                  <p className="text-foreground/80 leading-relaxed">
                    {t('culture.food.desc')}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Additional Culture Topics */}
          <div className="grid md:grid-cols-2 gap-8 mb-20">
            {/* Traditional Instruments */}
            <Card className="p-8 bg-card border-border hover:shadow-lg transition-all transform hover:scale-105 card-warm-hover">
              <div className="mb-4">
                <span className="text-4xl mb-4 block">🎸</span>
                <h3 className="text-2xl font-bold text-primary mb-3">{t('content.dombra')}</h3>
              </div>
              <p className="text-foreground/80 leading-relaxed">
                {t('content.dombra.desc')}
              </p>
            </Card>

            <Card className="p-8 bg-card border-border hover:shadow-lg transition-all transform hover:scale-105 card-warm-hover">
              <div className="mb-4">
                <span className="text-4xl mb-4 block">🎻</span>
                <h3 className="text-2xl font-bold text-primary mb-3">{t('content.kobyz')}</h3>
              </div>
              <p className="text-foreground/80 leading-relaxed">
                {t('content.kobyz.desc')}
              </p>
            </Card>

            {/* Traditional Crafts */}
            <Card className="p-8 bg-card border-border hover:shadow-lg transition-all transform hover:scale-105 card-warm-hover">
              <div className="mb-4">
                <span className="text-4xl mb-4 block">🧵</span>
                <h3 className="text-2xl font-bold text-primary mb-3">{t('content.carpet')}</h3>
              </div>
              <p className="text-foreground/80 leading-relaxed">
                {t('content.carpet.desc')}
              </p>
            </Card>

            <Card className="p-8 bg-card border-border hover:shadow-lg transition-all transform hover:scale-105 card-warm-hover">
              <div className="mb-4">
                <span className="text-4xl mb-4 block">✨</span>
                <h3 className="text-2xl font-bold text-primary mb-3">{t('content.embroidery')}</h3>
              </div>
              <p className="text-foreground/80 leading-relaxed">
                {t('content.embroidery.desc')}
              </p>
            </Card>
          </div>

          {/* Traditional Food & Lifestyle */}
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="p-8 bg-card border-border hover:shadow-lg transition-all transform hover:scale-105 card-warm-hover">
              <div className="mb-4">
                <span className="text-4xl mb-4 block">🍖</span>
                <h3 className="text-2xl font-bold text-primary mb-3">{t('content.beshbarmak')}</h3>
              </div>
              <p className="text-foreground/80 leading-relaxed">
                {t('content.beshbarmak.desc')}
              </p>
            </Card>

            <Card className="p-8 bg-card border-border hover:shadow-lg transition-all transform hover:scale-105 card-warm-hover">
              <div className="mb-4">
                <span className="text-4xl mb-4 block">🥛</span>
                <h3 className="text-2xl font-bold text-primary mb-3">{t('content.kumys')}</h3>
              </div>
              <p className="text-foreground/80 leading-relaxed">
                {t('content.kumys.desc')}
              </p>
            </Card>

            <Card className="p-8 bg-card border-border hover:shadow-lg transition-all transform hover:scale-105 card-warm-hover">
              <div className="mb-4">
                <span className="text-4xl mb-4 block">🏕️</span>
                <h3 className="text-2xl font-bold text-primary mb-3">{t('content.yurt')}</h3>
              </div>
              <p className="text-foreground/80 leading-relaxed">
                {t('content.yurt.desc')}
              </p>
            </Card>
          </div>

          {/* National Dress */}
          <div className="mt-12 bg-gradient-to-r from-amber-100/20 to-amber-50/20 rounded-lg p-12 border border-amber-200/30 hover:border-amber-300/50 transition-all">
            <div className="flex gap-6 items-start">
              <span className="text-6xl flex-shrink-0">👗</span>
              <div>
                <h3 className="text-3xl font-bold text-primary mb-4">{t('content.national.dress')}</h3>
                <p className="text-lg text-foreground/80 leading-relaxed">
                  {t('content.national.dress.desc')}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Lessons Section */}
      <section id="lessons" className="py-28 md:py-36 bg-card texture-warm">
        <div className="container">
          <h2 className="text-4xl md:text-5xl font-bold text-primary mb-8 text-center">
            {t('lessons.title')}
          </h2>
          <p className="text-lg text-foreground/80 text-center mb-20 max-w-3xl mx-auto">
            {t('lessons.intro')}
          </p>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Beginner */}
            <Card className="p-8 bg-background border-border hover:shadow-lg transition-all transform hover:scale-105 card-warm-hover flex flex-col">
              <div className="mb-6">
                <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center mb-4">
                  <BookOpen className="w-6 h-6 text-accent" />
                </div>
                <h3 className="text-2xl font-bold text-primary">{t('lessons.beginner')}</h3>
              </div>
              <p className="text-foreground/80 mb-8 leading-relaxed flex-grow">
                {t('lessons.beginner.desc')}
              </p>
              <Button 
                size="lg"
                className="w-full bg-accent hover:bg-accent/90 text-accent-foreground transition-all transform hover:scale-105"
                asChild
              >
                <a href={t('lessons.beginner.link')} target="_blank" rel="noopener noreferrer">
                  {t('lessons.button')}
                  <ArrowRight className="ml-2 w-4 h-4" />
                </a>
              </Button>
            </Card>

            {/* Intermediate */}
            <Card className="p-8 bg-background border-border hover:shadow-lg transition-all transform hover:scale-105 card-warm-hover flex flex-col">
              <div className="mb-6">
                <div className="w-12 h-12 rounded-lg bg-secondary/20 flex items-center justify-center mb-4">
                  <BookOpen className="w-6 h-6 text-secondary" />
                </div>
                <h3 className="text-2xl font-bold text-primary">{t('lessons.intermediate')}</h3>
              </div>
              <p className="text-foreground/80 mb-8 leading-relaxed flex-grow">
                {t('lessons.intermediate.desc')}
              </p>
              <Button 
                size="lg"
                className="w-full bg-secondary hover:bg-secondary/90 text-secondary-foreground transition-all transform hover:scale-105"
                asChild
              >
                <a href={t('lessons.intermediate.link')} target="_blank" rel="noopener noreferrer">
                  {t('lessons.button')}
                  <ArrowRight className="ml-2 w-4 h-4" />
                </a>
              </Button>
            </Card>

            {/* Advanced */}
            <Card className="p-8 bg-background border-border hover:shadow-lg transition-all transform hover:scale-105 card-warm-hover flex flex-col">
              <div className="mb-6">
                <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center mb-4">
                  <BookOpen className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-2xl font-bold text-primary">{t('lessons.advanced')}</h3>
              </div>
              <p className="text-foreground/80 mb-8 leading-relaxed flex-grow">
                {t('lessons.advanced.desc')}
              </p>
              <Button 
                size="lg"
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground transition-all transform hover:scale-105"
                asChild
              >
                <a href={t('lessons.advanced.link')} target="_blank" rel="noopener noreferrer">
                  {t('lessons.button')}
                  <ArrowRight className="ml-2 w-4 h-4" />
                </a>
              </Button>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12 md:py-16">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div>
              <h4 className="font-bold text-primary mb-4">Қазақ тілі</h4>
              <p className="text-sm text-foreground/70">
                Портал для изучения казахского языка и культуры
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">{t('footer.about')}</h4>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li><a href="#" className="hover:text-primary transition-colors">О сайте</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Миссия</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Команда</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">{t('footer.contact')}</h4>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li><a href="mailto:info@kazakh.kz" className="hover:text-primary transition-colors">Email</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Телефон</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Адрес</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">{t('footer.privacy')}</h4>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li><a href="#" className="hover:text-primary transition-colors">Политика конфиденциальности</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Условия использования</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Cookies</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-border pt-8">
            <p className="text-center text-sm text-foreground/70">
              {t('footer.copyright')}
            </p>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <PronunciationTrainer isOpen={isPronunciationOpen} onClose={() => setIsPronunciationOpen(false)} />
      <InteractiveDictionary isOpen={isDictionaryOpen} onClose={() => setIsDictionaryOpen(false)} />
    </div>
  );
}
