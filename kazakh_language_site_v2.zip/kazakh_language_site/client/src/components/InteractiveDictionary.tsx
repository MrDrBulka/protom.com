import { useState, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, Volume2, X } from 'lucide-react';

interface DictionaryEntry {
  kazakh: string;
  russian: string;
  meaning: string;
  example?: string;
  category: string;
}

const dictionaryEntries: DictionaryEntry[] = [
  { kazakh: 'Сәлем', russian: 'Sálem', meaning: 'Привет', category: 'Приветствия', example: 'Сәлем, достым!' },
  { kazakh: 'Рахмет', russian: 'Rakhmet', meaning: 'Спасибо', category: 'Вежливость' },
  { kazakh: 'Өтінем', russian: 'Ötinem', meaning: 'Пожалуйста', category: 'Вежливость' },
  { kazakh: 'Иә', russian: 'Iyá', meaning: 'Да', category: 'Базовые' },
  { kazakh: 'Жоқ', russian: 'Joq', meaning: 'Нет', category: 'Базовые' },
  { kazakh: 'Су', russian: 'Su', meaning: 'Вода', category: 'Природа' },
  { kazakh: 'Ағаш', russian: 'Ağash', meaning: 'Дерево', category: 'Природа' },
  { kazakh: 'Ат', russian: 'At', meaning: 'Лошадь', category: 'Животные' },
  { kazakh: 'Күн', russian: 'Kün', meaning: 'День/Солнце', category: 'Природа' },
  { kazakh: 'Түн', russian: 'Tün', meaning: 'Ночь', category: 'Природа' },
  { kazakh: 'Адам', russian: 'Adam', meaning: 'Человек', category: 'Люди' },
  { kazakh: 'Қыз', russian: 'Qız', meaning: 'Девушка', category: 'Люди' },
  { kazakh: 'Ұл', russian: 'Ul', meaning: 'Мальчик', category: 'Люди' },
];

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export default function InteractiveDictionary({ isOpen, onClose }: Props) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedEntry, setSelectedEntry] = useState<DictionaryEntry | null>(null);

  const categories = Array.from(new Set(dictionaryEntries.map(e => e.category)));

  const filteredEntries = useMemo(() => {
    return dictionaryEntries.filter(entry => {
      const matchesSearch = entry.kazakh.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           entry.russian.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           entry.meaning.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = !selectedCategory || entry.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, selectedCategory]);

  const handlePlayAudio = (word: string) => {
    const utterance = new SpeechSynthesisUtterance(word);
    utterance.lang = 'kk-KZ';
    window.speechSynthesis.speak(utterance);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">Интерактивный словарь</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-foreground/50" />
            <Input
              placeholder="Поиск по казахскому, русскому или значению..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`px-3 py-1 rounded-lg text-sm transition-all ${
                selectedCategory === null
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-secondary/20 text-foreground hover:bg-secondary/30'
              }`}
            >
              Все
            </button>
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1 rounded-lg text-sm transition-all ${
                  selectedCategory === cat
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary/20 text-foreground hover:bg-secondary/30'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Dictionary Entries */}
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {filteredEntries.length > 0 ? (
              filteredEntries.map((entry, idx) => (
                <div
                  key={idx}
                  onClick={() => setSelectedEntry(entry)}
                  className="p-4 bg-card border border-border rounded-lg hover:border-primary/50 hover:shadow-md transition-all cursor-pointer"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className="text-lg font-bold text-primary">{entry.kazakh}</p>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            handlePlayAudio(entry.kazakh);
                          }}
                          className="h-8 w-8 p-0"
                        >
                          <Volume2 className="w-4 h-4" />
                        </Button>
                      </div>
                      <p className="text-sm text-foreground/60">{entry.russian}</p>
                      <p className="text-sm text-foreground/80 mt-1">{entry.meaning}</p>
                    </div>
                    <span className="text-xs bg-accent/20 text-accent px-2 py-1 rounded">
                      {entry.category}
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-center text-foreground/60 py-8">
                Ничего не найдено
              </p>
            )}
          </div>

          {/* Selected Entry Detail */}
          {selectedEntry && (
            <div className="bg-gradient-to-r from-primary/10 to-accent/10 border-2 border-primary/30 rounded-lg p-4">
              <div className="flex items-start justify-between mb-3">
                <h3 className="text-xl font-bold text-primary">{selectedEntry.kazakh}</h3>
                <button
                  onClick={() => setSelectedEntry(null)}
                  className="text-foreground/50 hover:text-foreground"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="space-y-2 text-sm">
                <p><span className="font-semibold">Транслитерация:</span> {selectedEntry.russian}</p>
                <p><span className="font-semibold">Значение:</span> {selectedEntry.meaning}</p>
                {selectedEntry.example && (
                  <p><span className="font-semibold">Пример:</span> {selectedEntry.example}</p>
                )}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
