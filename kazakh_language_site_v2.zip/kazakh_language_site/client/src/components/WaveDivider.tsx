interface WaveDividerProps {
  fromColor: string;
  toColor: string;
  flip?: boolean;
}

export default function WaveDivider({ fromColor, toColor, flip = false }: WaveDividerProps) {
  const viewBox = flip ? '0 0 1200 120' : '0 0 1200 120';
  const pathData = flip
    ? 'M0,50 Q300,0 600,50 T1200,50 L1200,120 L0,120 Z'
    : 'M0,50 Q300,100 600,50 T1200,50 L1200,0 L0,0 Z';

  return (
    <svg
      viewBox={viewBox}
      preserveAspectRatio="none"
      className="w-full h-24 block"
    >
      <defs>
        <linearGradient id={`grad-${fromColor}-${toColor}`} x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor={fromColor} />
          <stop offset="100%" stopColor={toColor} />
        </linearGradient>
      </defs>
      <path
        d={pathData}
        fill={`url(#grad-${fromColor}-${toColor})`}
        opacity="1"
      />
    </svg>
  );
}
