import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Volume2, ChevronRight, ChevronLeft } from 'lucide-react';

interface PronunciationWord {
  kazakh: string;
  russian: string;
  meaning: string;
  category: string;
}

const pronunciationWords: PronunciationWord[] = [
  // Приветствия и знакомство
  { kazakh: 'Сәлем', russian: 'Sálem', meaning: 'Привет', category: 'Приветствия' },
  { kazakh: 'Сәлеметсіз бе', russian: 'Sálemetsiz be', meaning: 'Здравствуйте', category: 'Приветствия' },
  { kazakh: 'Қайырлы таң', russian: 'Qaıyrly tań', meaning: 'Доброе утро', category: 'Приветствия' },
  { kazakh: 'Қайырлы күн', russian: 'Qaıyrly kún', meaning: 'Добрый день', category: 'Приветствия' },
  { kazakh: 'Қайырлы кеш', russian: 'Qaıyrly kesh', meaning: 'Добрый вечер', category: 'Приветствия' },
  { kazakh: 'Сау болыңыз', russian: 'Saý bolyńyz', meaning: 'До свидания', category: 'Приветствия' },
  { kazakh: 'Көріскенше', russian: 'Kóriskenshe', meaning: 'До встречи', category: 'Приветствия' },

  // Вежливость
  { kazakh: 'Рахмет', russian: 'Rakhmet', meaning: 'Спасибо', category: 'Вежливость' },
  { kazakh: 'Өтінем', russian: 'Ötinem', meaning: 'Пожалуйста', category: 'Вежливость' },
  { kazakh: 'Кешіріңіз', russian: 'Keshirińiz', meaning: 'Извините', category: 'Вежливость' },
  { kazakh: 'Мархабат', russian: 'Marhabat', meaning: 'Не за что', category: 'Вежливость' },

  // Базовые слова
  { kazakh: 'Иә', russian: 'Iyá', meaning: 'Да', category: 'Базовые' },
  { kazakh: 'Жоқ', russian: 'Joq', meaning: 'Нет', category: 'Базовые' },
  { kazakh: 'Жақсы', russian: 'Jaqsy', meaning: 'Хорошо', category: 'Базовые' },
  { kazakh: 'Жаман', russian: 'Jaman', meaning: 'Плохо', category: 'Базовые' },
  { kazakh: 'Бар', russian: 'Bar', meaning: 'Есть', category: 'Базовые' },
  { kazakh: 'Жоқ', russian: 'Joq', meaning: 'Нет (отсутствует)', category: 'Базовые' },
  { kazakh: 'Керек', russian: 'Kerek', meaning: 'Нужно', category: 'Базовые' },

  // Семья
  { kazakh: 'Ана', russian: 'Ana', meaning: 'Мама', category: 'Семья' },
  { kazakh: 'Әке', russian: 'Áke', meaning: 'Папа', category: 'Семья' },
  { kazakh: 'Ата', russian: 'Ata', meaning: 'Дедушка', category: 'Семья' },
  { kazakh: 'Әже', russian: 'Áje', meaning: 'Бабушка', category: 'Семья' },
  { kazakh: 'Аға', russian: 'Aǵa', meaning: 'Брат (старший)', category: 'Семья' },
  { kazakh: 'Әпке', russian: 'Ápke', meaning: 'Сестра (старшая)', category: 'Семья' },
  { kazakh: 'Бала', russian: 'Bala', meaning: 'Ребенок', category: 'Семья' },

  // Числа
  { kazakh: 'Бір', russian: 'Bir', meaning: 'Один', category: 'Числа' },
  { kazakh: 'Екі', russian: 'Eki', meaning: 'Два', category: 'Числа' },
  { kazakh: 'Үш', russian: 'Úsh', meaning: 'Три', category: 'Числа' },
  { kazakh: 'Төрт', russian: 'Tórt', meaning: 'Четыре', category: 'Числа' },
  { kazakh: 'Бес', russian: 'Bes', meaning: 'Пять', category: 'Числа' },
  { kazakh: 'Алты', russian: 'Alty', meaning: 'Шесть', category: 'Числа' },
  { kazakh: 'Жеті', russian: 'Jeti', meaning: 'Семь', category: 'Числа' },
  { kazakh: 'Сегіз', russian: 'Segiz', meaning: 'Восемь', category: 'Числа' },
  { kazakh: 'Тоғыз', russian: 'Toǵyz', meaning: 'Девять', category: 'Числа' },
  { kazakh: 'Он', russian: 'On', meaning: 'Десять', category: 'Числа' },

  // Природа
  { kazakh: 'Су', russian: 'Su', meaning: 'Вода', category: 'Природа' },
  { kazakh: 'Ағаш', russian: 'Ağash', meaning: 'Дерево', category: 'Природа' },
  { kazakh: 'Тау', russian: 'Taý', meaning: 'Гора', category: 'Природа' },
  { kazakh: 'Күн', russian: 'Kún', meaning: 'Солнце/День', category: 'Природа' },
  { kazakh: 'Ай', russian: 'Aı', meaning: 'Луна/Месяц', category: 'Природа' },
  { kazakh: 'Жер', russian: 'Jer', meaning: 'Земля', category: 'Природа' },
  { kazakh: 'Аспан', russian: 'Aspan', meaning: 'Небо', category: 'Природа' },

  // Животные
  { kazakh: 'Ат', russian: 'At', meaning: 'Лошадь', category: 'Животные' },
  { kazakh: 'Ит', russian: 'It', meaning: 'Собака', category: 'Животные' },
  { kazakh: 'Мысық', russian: 'Mysyq', meaning: 'Кошка', category: 'Животные' },
  { kazakh: 'Қой', russian: 'Qoı', meaning: 'Овца', category: 'Животные' },
  { kazakh: 'Түйе', russian: 'Túıe', meaning: 'Верблюд', category: 'Животные' },
  { kazakh: 'Бүркіт', russian: 'Búrkit', meaning: 'Беркут', category: 'Животные' },

  // Еда
  { kazakh: 'Нан', russian: 'Nan', meaning: 'Хлеб', category: 'Еда' },
  { kazakh: 'Сүт', russian: 'Sút', meaning: 'Молоко', category: 'Еда' },
  { kazakh: 'Ет', russian: 'Et', meaning: 'Мясо', category: 'Еда' },
  { kazakh: 'Шай', russian: 'Shaı', meaning: 'Чай', category: 'Еда' },
  { kazakh: 'Су', russian: 'Su', meaning: 'Вода', category: 'Еда' },
  { kazakh: 'Алма', russian: 'Alma', meaning: 'Яблоко', category: 'Еда' },
];

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export default function PronunciationTrainer({ isOpen, onClose }: Props) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const filteredWords = selectedCategory
    ? pronunciationWords.filter(w => w.category === selectedCategory)
    : pronunciationWords;

  const currentWord = filteredWords[currentIndex];
  const categories = Array.from(new Set(pronunciationWords.map(w => w.category)));

  const handleNext = () => {
    if (currentIndex < filteredWords.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const handlePlayAudio = () => {
    // Используем Web Speech API для произношения
    const utterance = new SpeechSynthesisUtterance(currentWord.kazakh);
    utterance.lang = 'kk-KZ';
    window.speechSynthesis.speak(utterance);
  };

  const handleCategoryChange = (category: string) => {
    setSelectedCategory(selectedCategory === category ? null : category);
    setCurrentIndex(0);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl">Тренажер произношения</DialogTitle>
          <DialogDescription>
            Практикуйте казахское произношение с примерами
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Category Filter */}
          <div className="flex flex-wrap gap-2">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => handleCategoryChange(cat)}
                className={`px-4 py-2 rounded-lg transition-all ${
                  selectedCategory === cat
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary/20 text-foreground hover:bg-secondary/30'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Word Display */}
          {currentWord && (
            <div className="bg-card border-2 border-primary/20 rounded-lg p-8 text-center space-y-4">
              <div>
                <p className="text-sm text-foreground/60 mb-2">Казахское слово</p>
                <p className="text-4xl font-bold text-primary mb-4">{currentWord.kazakh}</p>
                <Button
                  onClick={handlePlayAudio}
                  className="bg-accent hover:bg-accent/90 text-accent-foreground"
                  size="lg"
                >
                  <Volume2 className="w-5 h-5 mr-2" />
                  Прослушать
                </Button>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-border">
                <div>
                  <p className="text-sm text-foreground/60">Транслитерация</p>
                  <p className="text-lg font-semibold text-foreground">{currentWord.russian}</p>
                </div>
                <div>
                  <p className="text-sm text-foreground/60">Значение</p>
                  <p className="text-lg font-semibold text-foreground">{currentWord.meaning}</p>
                </div>
              </div>
            </div>
          )}

          {/* Navigation */}
          <div className="flex items-center justify-between">
            <Button
              onClick={handlePrev}
              disabled={currentIndex === 0}
              variant="outline"
              size="lg"
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>

            <span className="text-sm text-foreground/60">
              {currentIndex + 1} / {filteredWords.length}
            </span>

            <Button
              onClick={handleNext}
              disabled={currentIndex === filteredWords.length - 1}
              variant="outline"
              size="lg"
            >
              <ChevronRight className="w-5 h-5" />
            </Button>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-border rounded-full h-2">
            <div
              className="bg-primary h-2 rounded-full transition-all"
              style={{
                width: `${((currentIndex + 1) / filteredWords.length) * 100}%`,
              }}
            />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
